package program2;

import java.util.Arrays;

public class Program2 
{

    public static void main(String[] args) 
    {
        //3 unsorted arrays
        //fetch=linear search (worst case scenario: last element)
        //insert=place at end
        //how many steps will each of these functions take
        //graph should have a straight line for fetch
        //graph should have a horizontal line for insert
        
        //10 element unsorted array
        int[] smallArray;
        smallArray=new int[10];
        fillArray(smallArray);
       
        //fetch the tenth element
        fetchUnsorted(smallArray);
        
        //insert an element at the end of the array
        insertUnsorted(smallArray);
        
        //100 element unsorted array
        int[] mediumArray;
        mediumArray=new int[100];
        fillArray(mediumArray);
        
        //fetch the hundredth element
        fetchUnsorted(mediumArray);
        
        //insert an element at the end of the array
        insertUnsorted(mediumArray);
        
        //1000 element unsorted array
        int[] largeArray;
        largeArray= new int [1000];
        fillArray(largeArray);
        
        //fetch the thousandth element
        fetchUnsorted(largeArray);
        
        //insert an element at the end of the array
        insertUnsorted(largeArray);
        
        //3 sorted arrays
        //fetch=binary search (worst case scenario: first or last element)
        //insert=fetch then insert (worst case scenario: first element)
        
        //sort the small array
        Arrays.sort(smallArray);
        //fetch the last element
        fetchSorted(smallArray, smallArray.length-1);
        //insert an element at the front of the array
        insertSorted(smallArray);
        
        //sort the medium array
        Arrays.sort(mediumArray);
        //fetch the last element
        fetchSorted(mediumArray, mediumArray.length-1);
        //insert an element at the front of the array
        insertSorted(mediumArray);
        
        
        //sort the large array
        Arrays.sort(largeArray);
        //fetch the last element
        fetchSorted(largeArray, largeArray.length-1);
       //insert an element at the front of the array
       insertSorted(largeArray);
        
        /*sample code from class
        int count=0;
        for(int j=0; j<=1000000; j++)
        {
            count=count+1;
        }    
        System.out.println("Your algorithm took " + count + " steps");
        */
        //use this data to make your algorithm plots.
        //don't make the plots by hand, use Excel
        //to get a scatterplot in Excel, click "Insert" and find the scatterplot
        //right click on the dots in the scatterplot, and add the appropriate line
    }
    
    
    public static int[] fillArray(int[] newArray)
    {
        for(int i=0; i<=newArray.length-1; i++) //loops for every element in the array
        {
            int num=(int)(1 + Math.random() *(100-1)); //adds a random number at each position
            newArray[i]=num;
        }
        return newArray; //the filled array is returned
    }        
    
    public static void fetchUnsorted(int[] array)
    {
        int count=0; //counts number of steps
        for(int i=0; i<=array.length-1; i++)
        {
            if(i==array.length-1) //if the last element is reached
            {
                System.out.println(array[i]); //print the element
            }   
            count=count+1; //each time the loop executes, a step is added
        }
        System.out.println("This array's algorithm took " + count + " steps");
    }        
    public static int deepCopy()
    {
        int node=(int)(1+ Math.random()*(100-1));
        return node; //creates a node to be inserted for the insert algorithms
    }        
    
    public static void insertUnsorted(int[] insertArray)
    {
     int next=insertArray.length-1; //initializes the integer "next"   
     insertArray[next]=deepCopy(); //a reference to the new data is placed at the end of the array
     next=next+1; //next is incremeneted to prepare for the next insert
     //this is O(c), it takes three steps no matter what
    }
    
    public static int fetchSorted(int[] arr, int search)
    {
        int countIt=1; //counts the number of steps, start at one because the while loop won't count the step where the element is found
        int low=0; //sets lower bound at index 0
        int high=arr.length-1; //sets upper bound to the last value in the array
        int current=0; //current position
        
        //while loop to find the element
        while(true)
        {
            current=(low+high)/2;
            
            //nested if statement
            if(arr[current]==search)//the current element is the one we're looking for
            {
               return current;
            }    
            
            else if(low>=high)
            {
                return current; //the element didn't exist in this array
                
            }   
            
            else
            {
                if(arr[current]<search)
                {
                    low=current+1; //look in upper half
                }
                else
                {
                    high=current-1; //look in lower half
                }    
                   
            }
           /* countIt=countIt+1;
            System.out.println("This algorithm took " + countIt + " steps");
           This code double checks how many steps that the fetch algorithm takes*/ 
        }    
            
    }       
    public static void insertSorted(int[] arr)
    {
      
        int j=fetchSorted(arr, 0); //fetches the first element in the array, taking the same number of steps as it did previously
      //  int count3=0;
        int insertElement=j-1;
        for(int i=arr.length-1; i>j; i--)
        {
            arr[i]=arr[i-1];
          //  count3=count3+1;
        }    
         arr[0]=insertElement;
       //System.out.println("The for loop repeated " + count3 + " times");
       //driver code to test how many times each loop repeats
      // add the number of times the loop repeats, the number of steps for the fetch, and 3 for the insert (constant), and you have the steps for delete.
       
    }      
            
}
